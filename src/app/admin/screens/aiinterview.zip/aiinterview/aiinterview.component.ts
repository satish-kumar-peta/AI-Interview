import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { interviewService } from 'src/app/core/services/aiinterview.service';
import { interviewaudio } from 'src/environments/environment.development';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aiinterview',
  templateUrl: './aiinterview.component.html',
  styleUrls: ['./aiinterview.component.css']
})
export class AiinterviewComponent implements OnInit, AfterViewInit, OnDestroy {

  /* ---------------- INTERVIEW ---------------- */
  currentIndex = 0;
  questions: any[] = [];
  currentQuestion: any;
  Audiourl = '';

  /* ---------------- AUDIO ---------------- */
  audioContext: any;

  /* ---------------- MIC & VISUALIZER ---------------- */
  micStream: any = null;
  micContext: any = null;
  micAnalyser: any = null;

  audioCanvas: any;
  micCanvas: any;

  /* ---------------- RECORDING ---------------- */
  mediaRecorder!: MediaRecorder;
  audioChunks: Blob[] = [];
  isRecording = false;

  /* ---------------- SPEECH ---------------- */
  studentSpeech = '';

  /* ---------------- SILENCE ---------------- */
  silenceTimer: any = null;
  SILENCE_LIMIT = 10000; // 10 sec
  silenceTimerRunning = false;

  /* ---------------- FLAGS ---------------- */
  isFirstPlayDone = false;
  questionAudioCompleted = false;

  constructor(
    private router: Router,
    private _interviewService: interviewService
  ) {}

  /* ================= INIT ================= */
  ngOnInit(): void {
    this._interviewService.getAiInterviewData().subscribe({
      next: (res) => {
        this.questions = res.data.data.questions;
        this.currentIndex = 0;
        this.currentQuestion = this.questions[0];
      },
      error: (err) => console.error(err)
    });
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.audioCanvas = this.makeVisualizer('audioCanvas');
      this.micCanvas = this.makeVisualizer('micCanvas');
      this.startMic();
    }, 100);
  }

  ngOnDestroy(): void {
    this.stopRecording();
    if (this.micStream) this.micStream.getTracks().forEach((t: any) => t.stop());
    if (this.audioContext) this.audioContext.close();
    if (this.micContext) this.micContext.close();
    if (this.silenceTimer) clearTimeout(this.silenceTimer);
  }

  /* ================= INTERVIEW ================= */
  startInterview() {
    if (this.isFirstPlayDone || !this.questions.length) return;

    this.isFirstPlayDone = true;
    this.loadQuestion();
    this.startAudio();
  }

  loadQuestion() {
    this.currentQuestion = this.questions[this.currentIndex];
    const { category, id } = this.currentQuestion;

    this.Audiourl =
      `${interviewaudio}/app/Assets/AI-Interview/${category}/${id}.mp3`;
  }

  /* ================= QUESTION AUDIO ================= */
  startAudio() {
    this.questionAudioCompleted = false;
    this.studentSpeech = '';

    if (!this.audioContext)
      this.audioContext = new AudioContext();

    const audio = new Audio(this.Audiourl);
    audio.crossOrigin = 'anonymous';

    const src = this.audioContext.createMediaElementSource(audio);
    const analyser = this.audioContext.createAnalyser();
    analyser.fftSize = 256;

    src.connect(analyser);
    analyser.connect(this.audioContext.destination);
    this.drawVisualizer(this.audioCanvas.ctx, analyser);

    audio.play();

    audio.onended = () => {
      this.questionAudioCompleted = true;
      this.startRecording();
      this.startSilenceTimer();
    };
  }

  /* ================= MIC ================= */
  async startMic() {
    this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });

    this.micContext = new AudioContext();
    const src = this.micContext.createMediaStreamSource(this.micStream);

    this.micAnalyser = this.micContext.createAnalyser();
    this.micAnalyser.fftSize = 256;

    src.connect(this.micAnalyser);
    this.drawVisualizer(this.micCanvas.ctx, this.micAnalyser);
  }

  /* ================= RECORDING ================= */
  startRecording() {
    if (!this.micStream || this.isRecording) return;

    this.audioChunks = [];
    this.mediaRecorder = new MediaRecorder(this.micStream, {
      mimeType: 'audio/webm'
    });

    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data.size) this.audioChunks.push(e.data);
    };

    this.mediaRecorder.start();
    this.isRecording = true;
  }

  stopRecording() {
    if (!this.mediaRecorder || !this.isRecording) return;

    this.mediaRecorder.stop();
    this.isRecording = false;

    this.mediaRecorder.onstop = () => {
      const blob = new Blob(this.audioChunks, { type: 'audio/webm' });
      this.sendAudioToBackend(blob);
    };
  }

  /* ================= BACKEND STT ================= */
  sendAudioToBackend(blob: Blob) {
    const fd = new FormData();
    fd.append('audio', blob);

    this._interviewService.speechToText(fd).subscribe({
      next: (res) => {
        if (res?.text) {
          this.studentSpeech += ' ' + res.text;
          this.resetSilenceTimer();
        }
      },
      error: (err) => console.error('STT error', err)
    });
  }

  /* ================= SILENCE ================= */
  startSilenceTimer() {
    if (!this.questionAudioCompleted) return;
    this.resetSilenceTimer();
  }

  resetSilenceTimer() {
    clearTimeout(this.silenceTimer);
    this.silenceTimer = setTimeout(() => {
      this.goToNextQuestion();
    }, this.SILENCE_LIMIT);
  }

  /* ================= NEXT ================= */
  goToNextQuestion() {
    this.stopRecording();

    if (this.currentIndex === this.questions.length - 1) {
      this.finishInterview();
      return;
    }

    this.currentIndex++;
    this.studentSpeech = '';
    this.loadQuestion();
    this.startAudio();
  }

  finishInterview() {
    this.stopRecording();
    if (this.micStream) this.micStream.getTracks().forEach((t: any) => t.stop());
    console.log('Interview completed');
  }

  /* ================= VISUALIZER ================= */
  makeVisualizer(id: string) {
    const canvas: any = document.getElementById(id);
    const ctx = canvas.getContext('2d');

    const resize = () => {
      canvas.width = canvas.offsetWidth * devicePixelRatio;
      canvas.height = canvas.offsetHeight * devicePixelRatio;
      ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    };

    resize();
    window.addEventListener('resize', resize);
    return { canvas, ctx };
  }

  drawVisualizer(ctx: any, analyser: any) {
    const dataArray = new Uint8Array(64);

    const loop = () => {
      requestAnimationFrame(loop);
      analyser.getByteFrequencyData(dataArray);
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

      const cx = ctx.canvas.width / devicePixelRatio / 2;
      const cy = ctx.canvas.height / devicePixelRatio / 2;

      for (let i = 0; i < 64; i++) {
        const v = dataArray[i] / 255;
        const len = 60 + v * 20;
        const angle = (Math.PI * 2 * i) / 64;

        ctx.strokeStyle = `rgba(0,200,255,${0.4 + v * 0.6})`;
        ctx.lineWidth = 4;

        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(angle) * 60, cy + Math.sin(angle) * 60);
        ctx.lineTo(cx + Math.cos(angle) * len, cy + Math.sin(angle) * len);
        ctx.stroke();
      }
    };
    loop();
  }
}
